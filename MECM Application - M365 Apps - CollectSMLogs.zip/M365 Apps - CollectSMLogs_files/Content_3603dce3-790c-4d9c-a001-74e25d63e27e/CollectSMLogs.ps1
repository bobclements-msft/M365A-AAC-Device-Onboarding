# Copyright (c) Microsoft Corporation. All rights reserved.
#
# Collecting local troubleshooting info related to Servivceability Manager
#

param (
[string] $zipfile
)

Function Log
{
    [CmdletBinding()]

    Param([Parameter(Mandatory=$true)][string]$content)

    $LogFile = "$env:Temp\zipsmlogs.log"
    $LogDate = get-date -format "MM/dd/yyyy HH:mm:ss"
    $LogLine = "$LogDate $content"
    Add-Content -Path $LogFile -Value $LogLine -ErrorAction SilentlyContinue
    Write-Host $content
}

if ($zipfile)
{
    $dest = $zipfile
}
else
{
    $dest = "$env:windir\temp\officesvcmgr_$env:computername.zip"
}

Log("Save the registry info to $dest")
Out-File -FilePath $env:temp\\bios.txt
Out-File -FilePath $env:temp\\c2r_store.txt
Out-File -FilePath $env:temp\\c2r_wowstore.txt
Out-File -FilePath $env:temp\\c2r_configure.txt
Out-File -FilePath $env:temp\\c2r_inventory.txt
Out-File -FilePath $env:temp\\c2rsvcmgr.txt
Out-File -FilePath $env:temp\\office_common.txt
Out-File -FilePath $env:temp\\office_gpo.txt
Out-File -FilePath $env:temp\\office_cloud.txt
Out-File -FilePath $env:temp\\windowsnt.txt
Out-File -FilePath $env:temp\\windows_logon.txt
Out-File -FilePath $env:temp\\windows_deliveryoptimization.txt
Out-File -FilePath $env:temp\\identity.txt
Out-File -FilePath $env:temp\\autoprovisioning.txt
Out-File -FilePath $env:temp\\licensing.txt
Out-File -FilePath $env:temp\\lastUser.txt
Out-File -FilePath $env:temp\\hkcuCommon.txt
reg export HKEY_LOCAL_MACHINE\HARDWARE\DESCRIPTION\System\BIOS $env:temp\\bios.txt /y
reg export HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Office\16.0\ClickToRunStore\Applications $env:temp\\c2r_store.txt /y
reg export HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Office\16.0\ClickToRunStore\Applications $env:temp\\c2r_wowstore.txt /y
reg export HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Office\ClickToRun\Configuration $env:temp\\c2r_configure.txt /y
reg export HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Office\ClickToRun\Inventory $env:temp\\c2r_inventory.txt /y
reg export HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Office\C2RSvcMgr $env:temp\\c2rsvcmgr.txt /y
reg export HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Office\Common $env:temp\\office_common.txt /y
reg export HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\office\16.0\common $env:temp\\office_gpo.txt /y
reg export HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\cloud\office\16.0\common $env:temp\\office_cloud.txt /y
reg export "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion" $env:temp\\windowsnt.txt /y
reg export HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\LogonUI $env:temp\\windows_logon.txt /y
reg export HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Config $env:temp\\windows_deliveryoptimization.txt /y
reg export HKEY_CURRENT_USER\SOFTWARE\Microsoft\Office\16.0\Common\Identity $env:temp\\identity.txt /y
reg export HKEY_CURRENT_USER\Software\Microsoft\Office\16.0\Common\AutoProvisioning $env:temp\\autoprovisioning.txt /y
reg export HKEY_CURRENT_USER\Software\Microsoft\Office\16.0\Common\Licensing\LicensingNext $env:temp\\licensing.txt /y
reg export HKEY_CURRENT_USER\Software\Microsoft\Office\16.0\Common\CloudPolicy $env:temp\\lastUser.txt /y
reg export HKEY_CURRENT_USER\Software\Microsoft\Office\Common $env:temp\\hkcuCommon.txt /y
Compress-Archive -update $env:temp\\bios.txt -DestinationPath $dest
Compress-Archive -update $env:temp\\c2r_store.txt -DestinationPath $dest
Compress-Archive -update $env:temp\\c2r_wowstore.txt -DestinationPath $dest
Compress-Archive -update $env:temp\\c2r_configure.txt -DestinationPath $dest
Compress-Archive -update $env:temp\\c2r_inventory.txt -DestinationPath $dest
Compress-Archive -update $env:temp\\c2rsvcmgr.txt -DestinationPath $dest
Compress-Archive -update $env:temp\\office_common.txt -DestinationPath $dest
Compress-Archive -update $env:temp\\office_gpo.txt -DestinationPath $dest
Compress-Archive -update $env:temp\\office_cloud.txt -DestinationPath $dest
Compress-Archive -update $env:temp\\windowsnt.txt -DestinationPath $dest
Compress-Archive -update $env:temp\\windows_logon.txt -DestinationPath $dest
Compress-Archive -update $env:temp\\windows_deliveryoptimization.txt -DestinationPath $dest
Compress-Archive -update $env:temp\\identity.txt -DestinationPath $dest
Compress-Archive -update $env:temp\\autoprovisioning.txt -DestinationPath $dest
Compress-Archive -update $env:temp\\licensing.txt -DestinationPath $dest
Compress-Archive -update $env:temp\\lastUser.txt -DestinationPath $dest
Compress-Archive -update $env:temp\\hkcuCommon.txt -DestinationPath $dest
$InventoryFile = "$env:PROGRAMDATA\\Microsoft\\Office\\SvcMgr\\Inventory_v2.txt"
if (Test-Path $InventoryFile)
{
    Compress-Archive -update $InventoryFile -DestinationPath $dest
}

Log("Save the event info to $dest")
Get-Eventlog -logname Application -source 'Application Error' -ErrorAction:SilentlyContinue | where-object {$_.message -like "*OfficeSvcMgr*"} | export-csv $env:temp\officsvcmgr_error.csv
Compress-Archive -update $env:temp\\officsvcmgr_error.csv -DestinationPath $dest

$serviceName = 'OfficeSvcManager'
$smService = Get-Service -Name $serviceName -ErrorAction:SilentlyContinue

$smService.Status

Log("Stop the SM service.")
Stop-Service -name $serviceName 

Log("Find all the log files related to SM components.")
$result = Get-ChildItem $env:windir\temp\*.log | select-string -pattern "dfalf"
$result.Path | foreach-object { Log("    $_") }

Log("Zip all files to $dest")
Compress-Archive -update $result.Path -DestinationPath $dest

Log("Restart SM Service")
Start-Service -name $serviceName 

$serviceName = 'ClickToRunSvc'

Log("Stop the C2R service.")
Stop-Service -name $serviceName 
Log("Find all the log files related to C2R components.")
$result = Get-ChildItem $env:windir\temp\*.log | select-string -pattern "aqkhc"
$result.Path | foreach-object { Log("    $_") }

Log("Zip all files to $dest")
Compress-Archive -update $result.Path -DestinationPath $dest

Log("Restart C2R Service")
Start-Service -name $serviceName 

Log("Quit the log collection process")